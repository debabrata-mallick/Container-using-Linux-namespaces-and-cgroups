I found this container code resources in internet in this link: https://github.com/osinstom/containers-impl-c
Please do consider this.

https://raw.githubusercontent.com/osinstom/containers-impl-c/master/src/01-cnt-uts.c
https://raw.githubusercontent.com/osinstom/containers-impl-c/master/src/02-cnt-mnt.c
https://raw.githubusercontent.com/osinstom/containers-impl-c/master/src/03-cnt-pid.c
https://raw.githubusercontent.com/osinstom/containers-impl-c/master/src/04-cnt-ipc.c
https://raw.githubusercontent.com/osinstom/containers-impl-c/master/src/05-cnt-user.c
https://raw.githubusercontent.com/osinstom/containers-impl-c/master/src/06-cnt-net.c
https://raw.githubusercontent.com/osinstom/containers-impl-c/master/src/00-cnt.c
https://raw.githubusercontent.com/osinstom/containers-impl-c/master/src/lib/netns.c
https://raw.githubusercontent.com/osinstom/containers-impl-c/master/src/lib/netns.h


