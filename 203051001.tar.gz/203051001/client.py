import socket
import time
# create a socket object
serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
                         

port = 3512

# connection to hostname on the port.
serversocket.connect(('192.168.1.2', port))                               

# Receive no more than 1024 bytes
msg = serversocket.recv(1024)
                                    
print(msg.decode("utf-8"))

time.sleep(0.5)

serversocket.close()
