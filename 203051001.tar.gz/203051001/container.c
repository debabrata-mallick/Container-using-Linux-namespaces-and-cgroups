//Source - http://cizixs.com/2017/08/29/linux-namespace


#define _GNU_SOURCE
#include <sched.h>
#include <sys/wait.h>
#include <sys/mount.h>
#include <sys/utsname.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>
#include <string.h>


#define STACK_SIZE (1024*1024)
static char container_stack[STACK_SIZE];

#define errExit(code, msg); {if(code == -1){perror(msg); exit(-1);} }


char* const container_args[] = {
    "/bin/bash",
    NULL
};

struct child_args {
    char *hostname;
    int pipe_fd[2];
};

void update_map(char *file, int inside_id, int outside_id, int len) {
    FILE *mapfd = fopen(file, "w");
    if (mapfd == NULL) {
        errExit(-1, "open user map");
    }
    fprintf(mapfd, "%d %d %d", inside_id, outside_id, len);
    fclose(mapfd);
}

void update_uid_map(pid_t pid, int inside_id, int outside_id, int len) {
    char map_path[PATH_MAX];
    sprintf(map_path, "/proc/%ld/uid_map", (long) pid);
    update_map(map_path, inside_id, outside_id, len);
}

void update_gid_map(pid_t pid, int inside_id, int outside_id, int len) {
    char map_path[PATH_MAX];
    sprintf(map_path, "/proc/%ld/gid_map", (long) pid);
    update_map(map_path, inside_id, outside_id, len);
}

static int container_func(void *arg)
{
    struct child_args *args = (struct child_args *) arg;
    char *hostname = args->hostname;

    char ch;
    close(args->pipe_fd[1]);
    if (read(args->pipe_fd[0], &ch, 1) != 0) {
        errExit(-1, "read pipe");
    }

    pid_t pid = getpid();
    printf("Container[%d] - inside the container!\n", pid);

    struct utsname uts;
    if (sethostname(hostname, strlen(hostname)) == -1) {
        errExit(-1, "sethostname");
    };

    system("mount --make-private /proc");
    if (mount("proc", "/proc", "proc", 0, NULL) != 0) {
        errExit(-1, "proc");
    };

    system("mount --make-private /tmp");
    if (mount("tmpfs", "/tmp", "tmpfs", 0, NULL) != 0){
        errExit(-1, "tmp");
    };

    if (uname(&uts) == -1){
        errExit(-1, "uname");
    }
    printf("Container[%d] - container uts.nodename: [%s]!\n", pid, uts.nodename);

    execv(container_args[0], container_args);

    printf("Container[%d] - oops!\n", pid);
    return 1;
}

int main(int argc, char *argv[])
{
    char *hostname;
    struct child_args args;

    if (argc < 2) {
        hostname = "container";
    } else {
        hostname = argv[1];
    }

    args.hostname = hostname;
    if (pipe(args.pipe_fd) == -1) {
        errExit(-1, "pipe");
    }

    pid_t pid = getpid();

    struct utsname uts;
    if (uname(&uts) == -1){
        errExit(-1, "uname")
    }
    printf("Parent[%d] - parent uts.nodename: [%s]!\n", pid, uts.nodename);

    pid_t child_pid = clone(container_func, 
                    container_stack + sizeof(container_stack),

                    CLONE_NEWUTS | CLONE_NEWPID | CLONE_NEWNS | CLONE_NEWIPC | CLONE_NEWUSER | SIGCHLD,
                    &args); 
    errExit(child_pid, "clone");

    const int uid=getuid(), gid=getgid();
    update_uid_map(child_pid, 0, uid, 1);
    update_gid_map(child_pid, 0, gid, 1);
    printf("Parent[%d] - user and group id mapping done...", pid);
    close(args.pipe_fd[1]);

    waitpid(child_pid, NULL, 0);

    printf("Parent[%d] - container exited!\n", pid);
    return 0;
}
