#define _GNU_SOURCE
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <sched.h>
#include <signal.h>
#include <unistd.h>

#define STACK_SIZE (1024*1024)
static char container_stack[STACK_SIZE];

char* const container_args[] = {
    "/bin/bash",
    NULL
};

int cnt_main(void* arg){
    execv(container_args[0], container_args);
    printf("Wrong!\n");
    return 1;
}

int main(){
    printf("Parent container!\n");
    int flags = SIGCHLD | CLONE_NEWNET;
    int cnt_pid = clone(cnt_main, container_stack + STACK_SIZE, flags, NULL);
    waitpid(cnt_pid, NULL, 0);
    printf("Parent container stopped!\n");
    return 0;
}
