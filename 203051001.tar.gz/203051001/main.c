#define _GNU_SOURCE
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/mount.h>
#include <sys/utsname.h>
#include <stdio.h>
#include <sched.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>  // system()
#include <limits.h>
#include <string.h>

#define STACK_SIZE (1024*1024)
static char container_stack[STACK_SIZE];

char* const container_args[] = {
    "/bin/bash",
    NULL
};

int cnt_main(void* arg){

    sethostname("container", 10);
    system("mount -t proc proc /proc");
    execv(container_args[0], container_args);
    printf("Wrong!\n");
    return 1;
}

int create_cnt(void)
{
    char *cmd[] = { "/bin/bash", NULL };

    chroot("/home/avijit/rootfs");
    chdir("/");
    execv("/bin/bash", cmd);
    perror("exec");
    exit(EXIT_FAILURE);
}

int child(void *args)
{
    (void)args;
    create_cnt();
    return (0);
}

int main(){

    printf("Parent Container!\n");
    int flags = SIGCHLD | CLONE_NEWUTS | CLONE_NEWIPC | CLONE_NEWPID | CLONE_NEWNS | CLONE_NEWNET;
    int cnt_pid = clone(cnt_main, container_stack + STACK_SIZE, flags, NULL);
    waitpid(cnt_pid, NULL, 0);
    printf("Parent container stopped!\n");
    return 0;
}
